document.getElementById("register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const existe = await fetch(`http://localhost:3000/usuarios?email=${email}`);
  const usuarios = await existe.json();
  if (usuarios.length > 0) {
    document.getElementById("mensaje").textContent = "Correo ya registrado.";
    return;
  }

  await fetch("http://localhost:3000/usuarios", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, role: "user" })
  });

  document.getElementById("mensaje").textContent = "Registro exitoso. Inicia sesión.";
});