const user = JSON.parse(localStorage.getItem("usuario"));
const tareaForm = document.getElementById("tarea-form");
const lista = document.getElementById("tarea-lista");

if (!user || user.role !== "user") location.href = "index.html";

function cerrarSesion() {
  localStorage.removeItem("usuario");
  location.href = "index.html";
}

function cargarTareas() {
  fetch(`http://localhost:3000/tareas?userId=${user.id}`)
    .then(res => res.json())
    .then(data => {
      lista.innerHTML = "";
      data.forEach(t => {
        lista.innerHTML += `
          <tr>
            <td>${t.titulo}</td>
            <td>${t.descripcion}</td>
            <td>
              <button onclick="editar(${t.id})">✏️</button>
              <button onclick="eliminar(${t.id})">🗑️</button>
            </td>
          </tr>`;
      });
    });
}

tareaForm.addEventListener("submit", async e => {
  e.preventDefault();
  const titulo = document.getElementById("titulo").value;
  const descripcion = document.getElementById("descripcion").value;

  await fetch("http://localhost:3000/tareas", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ titulo, descripcion, userId: user.id })
  });

  tareaForm.reset();
  cargarTareas();
});

function eliminar(id) {
  fetch(`http://localhost:3000/tareas/${id}`, { method: "DELETE" })
    .then(cargarTareas);
}

function editar(id) {
  fetch(`http://localhost:3000/tareas/${id}`)
    .then(res => res.json())
    .then(t => {
      document.getElementById("titulo").value = t.titulo;
      document.getElementById("descripcion").value = t.descripcion;
      tareaForm.onsubmit = async function (e) {
        e.preventDefault();
        await fetch(`http://localhost:3000/tareas/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            titulo: document.getElementById("titulo").value,
            descripcion: document.getElementById("descripcion").value,
            userId: user.id
          })
        });
        tareaForm.reset();
        tareaForm.onsubmit = originalSubmit;
        cargarTareas();
      };
    });
}

const originalSubmit = tareaForm.onsubmit;
cargarTareas();