document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const res = await fetch(`http://localhost:3000/usuarios?email=${email}&password=${password}`);
  const data = await res.json();

  if (data.length === 1) {
    localStorage.setItem("usuario", JSON.stringify(data[0]));
    window.location.href = data[0].role === "admin" ? "admin.html" : "tareas.html";
  } else {
    document.getElementById("error-msg").textContent = "Credenciales inválidas";
  }
});