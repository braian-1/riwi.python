const admin = JSON.parse(localStorage.getItem("usuario"));
if (!admin || admin.role !== "admin") location.href = "index.html";

function cerrarSesion() {
  localStorage.removeItem("usuario");
  location.href = "index.html";
}

const listaTareas = document.getElementById("tarea-lista");
const listaUsuarios = document.getElementById("usuarios-lista");

async function cargarUsuarios() {
  const res = await fetch("http://localhost:3000/usuarios");
  const usuarios = await res.json();
  listaUsuarios.innerHTML = usuarios.map(u => `<li>${u.email} (${u.role})</li>`).join("");
}

async function cargarTareas() {
  const res = await fetch("http://localhost:3000/tareas");
  const tareas = await res.json();
  const usuarios = await fetch("http://localhost:3000/usuarios").then(r => r.json());

  listaTareas.innerHTML = tareas.map(t => {
    const usuario = usuarios.find(u => u.id === t.userId);
    return `
      <tr>
        <td>${usuario?.email || 'Desconocido'}</td>
        <td>${t.titulo}</td>
        <td>${t.descripcion}</td>
        <td><button onclick="eliminar(${t.id})">🗑️</button></td>
      </tr>`;
  }).join("");
}

function eliminar(id) {
  fetch(`http://localhost:3000/tareas/${id}`, { method: "DELETE" })
    .then(cargarTareas);
}

cargarUsuarios();
cargarTareas();