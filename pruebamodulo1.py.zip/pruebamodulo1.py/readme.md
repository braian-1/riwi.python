Para ingresar al sistema le va a pedir al usuario si desea ingresar al sistema o no, si escoge uno ingresa y si escoge dos no ingresa.

Aquí el usuario escogió la opción uno y al ingresar le va a dar un menú de opciones y ya dependiendo lo que escoja lo lleva a hacer el proceso.

Aquí el usuario escogió la opción uno el sistema le va a pedir que ingrese un producto, si el producto ya se encuentra en el inventario le va a decir que ya esta y si no 
el sistema le pedirá el precio y cantidad.

Si el usuario al estar en el menú ingresa la opción dos el sistema le va a pedir que producto desea buscar y se lo va a mostrar con el nombre del producto,precio y cantidad, y si el producto no se encuentra en el inventario le va a decir que no se encuentra.

Si el usuario en el menú escoge la opción tres, va a poder elegir  a que producto le va a cambiar el precio, si ingresa un numero negativo le va a decir que es una opción invalida,pero si el precio es un numero positivo le va a decir que el precio ha sido cambiado.

Si el usuario en el menú escoge al opción cuatro, va a poder elegir que producto desea borrar del inventario, si el producto existe le va a decir que el producto esta en el inventario y que ha sido eliminado del inventario, si no existe le dice que el producto no esta en el inventario.

Si el usuario en el menú escoge la opción cinco, le va a mostrar el calculo de cada producto que cantidad de dinero hay en el producto
y si va agregando mas productos también se los va a mostrar.
 
Si en el menú el usuario escoge la opción seis, le va a mostrar todos los productos que hay en el inventario con su debido valor y cantidad disponible y también con los productos que agregue el usuario.

Si el usuario selecciona el siete que es salir lo saca del sistema.






